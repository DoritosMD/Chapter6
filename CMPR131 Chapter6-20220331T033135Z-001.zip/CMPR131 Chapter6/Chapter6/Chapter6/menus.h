#pragma once
#include <iostream>
#include <string>
using namespace std;

//Precondition: NA
//Postcondition: displays main menu options
void displayMainMenu(void)
{
    cout << "\n\tChapter 6: Non-template and Template Containers by Matthew Batres, Eduardo Ortiz, Victor Huerta, Alavi Isa" << endl;
    cout << "\t" + string(100, char(205)) << endl;
    cout << "\t\t1> Non-template MyBag container of int" << endl;
    cout << "\t\t2> Template MyBag<double> container" << endl;
    cout << "\t\t3> Application using MyBag container" << endl;
    cout << "\t" + string(100, char(196)) << endl;
    cout << "\t\t0> exit" << endl;
    cout << "\t" + string(100, char(205)) << endl;
}

//Precondition: NA
//Postcondition: displays option one menu options
void displayOptionOneMenu(void)
{
    cout << "\n\t1> Non-template MyBag of integers" << endl;
    cout << "\t" + string(100, char(205)) << endl;
    cout << "\t\tA> clear" << endl;
    cout << "\t\tB> insert" << endl;
    cout << "\t\tC> search" << endl;
    cout << "\t\tD> remove" << endl;
    cout << "\t\tE> sort" << endl;
    cout << "\t\tF> display" << endl;
    cout << "\t" + string(100, char(196)) << endl;
    cout << "\t\t0> return" << endl;
    cout << "\t" + string(100, char(205)) << endl;
}

//Precondition: NA
//Postcondition: displays option two menu options
void displayOptionTwoMenu(void)
{
    cout << "\n\t2> Template MyBag<double> container" << endl;
    cout << "\t" + string(100, char(205)) << endl;
    cout << "\t\tA> clear" << endl;
    cout << "\t\tB> insert" << endl;
    cout << "\t\tC> search" << endl;
    cout << "\t\tD> remove" << endl;
    cout << "\t\tE> sort" << endl;
    cout << "\t\tF> display" << endl;
    cout << "\t" + string(100, char(196)) << endl;
    cout << "\t\t0> return" << endl;
    cout << "\t" + string(100, char(205)) << endl;
}

//Precondition: NA
//Postcondition: displays option three menu options
void displayOptionThreeMenu(void)
{
    cout << "\n\t3> Courses using MyBags of integers, strings, doubles, and chars" << endl;
    cout << "\t" + string(100, char(205)) << endl;
    cout << "\t\tA> Specify the number of courses" << endl;
    cout << "\t\tB> Read in data file and insert into courses" << endl;
    cout << "\t\tC> Search for a student record from a course" << endl;
    cout << "\t\tD> Remove a student record from a course" << endl;
    cout << "\t\tE> Display course(s)" << endl;
    cout << "\t" + string(100, char(196)) << endl;
    cout << "\t\t0> return" << endl;
    cout << "\t" + string(100, char(205)) << endl;
}